// INSANYCK STEP 4
import Document, { Html, Head, Main, NextScript, DocumentContext } from "next/document";

class MyDocument extends Document {
  static async getInitialProps(ctx: DocumentContext) {
    const initialProps = await Document.getInitialProps(ctx);
    return { ...initialProps };
  }

  render() {
    // Locale resolvido pelo Next (Pages Router) em SSR
    const currentLocale = (this.props as any).__NEXT_DATA__?.locale || "pt";
    const pagePath = (this.props as any).__NEXT_DATA__?.page || "/";
    const ogLocale = currentLocale === "pt" ? "pt_BR" : "en_US";

    // Base URL para hreflang absolutos
    const baseUrl = process.env.NEXT_PUBLIC_URL || "https://insanyck.com";
    
    // Helpers com URLs absolutos para alternates
    const hrefPt = `${baseUrl}${pagePath === "/" ? "/" : pagePath}`;
    const hrefEn = `${baseUrl}${pagePath === "/" ? "/en" : `/en${pagePath}`}`;

    return (
      <Html lang={currentLocale}>
        <Head>
          {/* DNS prefetch control */}
          <meta httpEquiv="x-dns-prefetch-control" content="on" />
          
          {/* Resource hints for Google Fonts */}
          <link rel="preconnect" href="https://fonts.googleapis.com" crossOrigin="" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
          <link rel="dns-prefetch" href="//fonts.googleapis.com" />
          <link rel="dns-prefetch" href="//fonts.gstatic.com" />
          
          {/* Resource hints for Stripe */}
          <link rel="preconnect" href="https://js.stripe.com" />
          <link rel="dns-prefetch" href="//js.stripe.com" />

          {/* OG locale por idioma */}
          <meta property="og:locale" content={ogLocale} />

          {/* Alternates hreflang */}
          <link rel="alternate" hrefLang="pt" href={hrefPt} />
          <link rel="alternate" hrefLang="en" href={hrefEn} />
          <link rel="alternate" hrefLang="x-default" href={hrefPt} />

          {/* Mantém PWA funcionando */}
          <link rel="manifest" href="/manifest.json" />
          <meta name="theme-color" content="#000000" />
        </Head>
        <body>
          <Main />
          <NextScript />
        </body>
      </Html>
    );
  }
}

export default MyDocument;
