// INSANYCK  Cart visuals signature (minimal export)
export const CartDrawerSignature = () => null;